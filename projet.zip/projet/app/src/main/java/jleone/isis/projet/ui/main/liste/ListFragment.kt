package jleone.isis.projet.ui.main.liste

import androidx.fragment.app.Fragment

class ListFragment : Fragment() {
}
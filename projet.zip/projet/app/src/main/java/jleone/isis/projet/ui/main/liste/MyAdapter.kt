package jleone.isis.projet.ui.main.liste

import android.text.Layout
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import jleone.isis.projet.R
import jleone.isis.projet.model.Photo

class MyAdapter(val photo : List<Photo>) :

    RecyclerView.Adapter<MyAdapter.MyViewHolder>() {
    // un ViewHolder permet de stocker la vue de chaque item de la liste
    class MyViewHolder(val v: Layout) : RecyclerView.ViewHolder(v)
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyAdapter.MyViewHolder {
        val layout = LayoutInflater.from(parent.context).inflate(R.layout.photo,parent,false)
        return MyViewHolder(layout as Layout)}

    override fun getItemCount(): Int = photo.size

    override fun onBindViewHolder(holder: MyAdapter.MyViewHolder, position: Int){
        imageview= layout.findViewById<ImageView>(R.id.imageView)
        textview= layout.findViewById<TextView>(R.id.textView)
        textview.text= users[position].nom
    }
    }

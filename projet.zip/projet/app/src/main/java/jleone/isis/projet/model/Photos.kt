package jleone.isis.projet.model

import android.provider.ContactsContract

class Photos(
    val page: Integer,
    val pages: Integer,
    val perpage: Integer,
    val total: String,
    val photo: List<Photo>) {
}
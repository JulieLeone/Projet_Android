package jleone.isis.projet.ui.main.main

import androidx.lifecycle.ViewModelProviders
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.lifecycle.Observer
import com.bumptech.glide.Glide
import jleone.isis.projet.R

class MainFragment : Fragment() {

    companion object {
        fun newInstance() = MainFragment()
    }

    private lateinit var viewModel: MainViewModel
    private lateinit var imageview : ImageView
    private lateinit var next : Button
    private lateinit var textview: TextView


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?): View {

        var layout :View = inflater.inflate(R.layout.main_fragment, container, false)
        imageview= layout.findViewById<ImageView>(R.id.imageView)
        textview= layout.findViewById<TextView>(R.id.textView)
        next= layout.findViewById<Button>(R.id.next)
        next.setOnClickListener( {
            viewModel.nextPhoto()
        })
      return layout
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel = ViewModelProviders.of(this).get(MainViewModel::class.java)
        // TODO: Use the ViewModel
        val photo= viewModel.photo
        photo.observe(requireActivity(), Observer { photo ->
            textview.text = photo?.title
            val url = "https://farm" + photo.farm + ".staticflickr.com/" + photo.server + "/" + photo.id + "_" + photo.secret + ".jpg"
            Glide.with(requireActivity()).load(url).into(imageview);
        })
    }

}
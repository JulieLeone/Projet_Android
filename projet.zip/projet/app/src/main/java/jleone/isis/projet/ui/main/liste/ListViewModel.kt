package jleone.isis.projet.ui.main.liste

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import jleone.isis.projet.model.Photo
import jleone.isis.projet.model.Photos
import jleone.isis.projet.model.SearchResult
import jleone.isis.projet.repository.Repository
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ListViewModel : ViewModel() {
    var photo = MutableLiveData<Photo>()
    var photos = MutableLiveData<Photos>()
    var i=0
    init {
        Repository().getPhotos(object : Callback<SearchResult> {
            override fun onFailure(call: Call<SearchResult>, t: Throwable) {
                Log.e("erreur", "erreur")
            }

            override fun onResponse(call: Call<SearchResult>, response: Response<SearchResult>) {
                photos.value=response.body()?.photos
                response.body()?.photos?.photo?.get(0)?.let  { photo.value = it }  // let => Permet de tester si le membre de gauche est nul
            }
        })
    }
    fun nextPhoto() {
        i+=1
        if(i>= photos.value?.photo?.size!!){
            i=0
        }
        photo.value = photos.value?.photo?.get(i)
    }
}
